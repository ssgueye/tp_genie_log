//package tp4;
import java.util.*;
import java.time;

public class Vol
{
	private String identifiant;
	private ZonedDateTime depart = new ZonedDateTime();
	private ZonedDateTime arrivee = new ZonedDateTime();

	public Vol()
	{

	}
	public Vol(String identifiant, ZonedDateTime depart, ZonedDateTime arrivee)
	{
		this.identifiant = identifiant;
		this.depart = depart;
		this.arrivee = arrivee;
	}
	public getIdentifiant()
	{
		return this.identifiant;
	}
	public getDepart()
	{
		return this.depart;
	}
	public getArrivee()
	{
		return this.arrivee;
	}

	public ZonedDateTime duree()
	{
		return (this.arrivee - this.depart);
	}
	public String ouvrir()
	{
		String ouvert = "Ouvert";
		return ouvert;
	}
	public String fermee()
	{
		String fermee = "Fermée";
		return fermee;
	}
}