import java.lang.*;
import java.util.*;
import java.time.*;


public class Reservation
{
	public Date date = new Date();
	public Double identifiant;
	public String etat;
	

	public Reservation()
	{

	}
	public Reservation(Date date, Double identifiant, String etat)
	{
		this.date = date;
		this.identifiant = identifiant;
		this.etat = etat;
	}

	public Date getDate()
	{
		return this.date;
	}
	public Double getIdentifiant()
	{
		return this.identifiant;
	}
	public String getEtat()
	{
		return this.etat;
	}

	public String annuler()
	{
		this.etat= "ANNULE";
		return this.etat;
	}
	public String confirmer()
	{
		this.etat= "CONFIRME";
		return this.etat;
	}
	public String payer()
	{
		this.etat= "PAYE";
		return this.etat;
	}
	public String toString()
	{
		return "Date:"+getDate()+"\nIdentif:"+getIdentifiant()+"\nEtat:"+getEtat();
	}
}