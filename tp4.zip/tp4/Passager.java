//package tp4;
import java.util.*;
import java.time;

public class Passager
{
	private String nom;
	private String contact;

	public Passager()
	{

	}
}