import java.lang.*;
//import java.util.*;
//import java.time;


public class Client
{
	private String nom;
	private String paiement;
	private String contact;
	private String reference;
	private Reservation r = new Reservation();
	private Vol v = new Vol();

	public Client()
	{

	}
	public Client(String nom, String paiement, String contact, String reference)
	{
		this.nom = nom;
		this.paiement = paiement;
		this.contact = contact;
		this.reference = reference;
	}

	public String getNom()
	{
		return this.nom;
	}
	public String getPaiement()
	{
		this.paiement = this.r.getEtat();
		return this.paiement;
	}	
	public String getContact()
	{
		return this.contact;
	}
	public String getReference()
	{
		return this.reference;
	}

	public String toString()
	{
		return "Réservation Client:\n\tNom:"+getNom()+"\n\tPaiement:"+getPaiement()+"\n\tContact:"+getContact()+"\n\tRéférence:"+getReference()+"Date"+r.getDate()+ "Num. réservation:"+r.getIdentifiant()+"Numéro Vol:"+v.getIdentifiant()+"Depart:"+v.getDepart()+"Arrivée:"+v.getArrivee()+"Durée:"+v.duree();
			}
}