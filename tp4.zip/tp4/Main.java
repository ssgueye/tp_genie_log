import java.lang.*;
import java.util.*;
import java.time.*;

public class Main 
{
	public static void main(String[] args)
	{
		Client c1= new Client("Saliou", "200 euros", "0758837665", "#3524Y4");
		Reservation r1 = new Reservation(new Date(16,10,2019), 34.0, "PAYE");
		
		System.out.println("=================================");
		System.out.println(c1.toString());
		System.out.println(r1.toString());
		r1.confirmer();
		System.out.println("=================================");
		
		
		
	}
}