public class Function
{
	public void function(String name)
		{
			System.out.println("hello world " + name + " !") ;
		}
}