public class Main
{
	public static void main(String[] args)
	{
		Function function = new Function() ;
		function.function(args[0]) ;
	}
}